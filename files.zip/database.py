"""
Canary Platform — Database Layer
SQLite — two tables: tokens (planted) and triggers (fired).
"""

import sqlite3
import json
from datetime import datetime
import sys
sys.path.insert(0, '/home/claude/canary-platform')
from config.settings import DATABASE_PATH


def get_connection():
    conn = sqlite3.connect(str(DATABASE_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    DATABASE_PATH.parent.mkdir(exist_ok=True)
    conn = get_connection()
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS tokens (
            id           TEXT PRIMARY KEY,
            type         TEXT NOT NULL,
            label        TEXT NOT NULL,
            description  TEXT,
            tracking_url TEXT NOT NULL,
            file_path    TEXT,
            metadata     TEXT DEFAULT '{}',
            created_at   TEXT NOT NULL,
            is_active    INTEGER DEFAULT 1
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS triggers (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            token_id        TEXT NOT NULL,
            triggered_at    TEXT NOT NULL,
            ip_address      TEXT,
            user_agent      TEXT,
            referer         TEXT,
            ja3_fingerprint TEXT,
            canvas_fp       TEXT,
            geo_country     TEXT,
            geo_city        TEXT,
            extra_headers   TEXT DEFAULT '{}',
            suspicion_score REAL DEFAULT 0.0,
            is_alert_sent   INTEGER DEFAULT 0,
            FOREIGN KEY (token_id) REFERENCES tokens(id)
        )
    """)

    conn.commit()
    conn.close()


def save_token(data: dict) -> str:
    conn = get_connection()
    conn.execute("""
        INSERT INTO tokens (id, type, label, description, tracking_url, file_path, metadata, created_at)
        VALUES (:id, :type, :label, :description, :tracking_url, :file_path, :metadata, :created_at)
    """, {**data, "metadata": json.dumps(data.get("metadata", {})),
          "created_at": datetime.utcnow().isoformat()})
    conn.commit()
    conn.close()
    return data["id"]


def get_all_tokens() -> list:
    conn = get_connection()
    rows = conn.execute("""
        SELECT t.*, COUNT(tr.id) as trigger_count
        FROM tokens t
        LEFT JOIN triggers tr ON t.id = tr.token_id
        GROUP BY t.id ORDER BY t.created_at DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_token(token_id: str):
    conn = get_connection()
    row = conn.execute("SELECT * FROM tokens WHERE id = ?", (token_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def deactivate_token(token_id: str):
    conn = get_connection()
    conn.execute("UPDATE tokens SET is_active = 0 WHERE id = ?", (token_id,))
    conn.commit()
    conn.close()


def save_trigger(data: dict) -> int:
    conn = get_connection()
    cur = conn.execute("""
        INSERT INTO triggers (
            token_id, triggered_at, ip_address, user_agent, referer,
            ja3_fingerprint, canvas_fp, geo_country, geo_city,
            extra_headers, suspicion_score
        ) VALUES (
            :token_id, :triggered_at, :ip_address, :user_agent, :referer,
            :ja3_fingerprint, :canvas_fp, :geo_country, :geo_city,
            :extra_headers, :suspicion_score
        )
    """, {**data, "triggered_at": datetime.utcnow().isoformat(),
          "extra_headers": json.dumps(data.get("extra_headers", {}))})
    conn.commit()
    tid = cur.lastrowid
    conn.close()
    return tid


def get_triggers(token_id: str = None) -> list:
    conn = get_connection()
    if token_id:
        rows = conn.execute(
            "SELECT * FROM triggers WHERE token_id = ? ORDER BY triggered_at DESC",
            (token_id,)).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM triggers ORDER BY triggered_at DESC LIMIT 100").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_recent_alerts(limit: int = 20) -> list:
    conn = get_connection()
    rows = conn.execute("""
        SELECT tr.*, t.label, t.type FROM triggers tr
        JOIN tokens t ON tr.token_id = t.id
        WHERE tr.suspicion_score >= 0.4
        ORDER BY tr.triggered_at DESC LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]
