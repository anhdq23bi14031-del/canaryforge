"""
Capture Engine — handles incoming token triggers.
Collects all available metadata, scores suspicion, saves to DB.
"""

import sys
sys.path.insert(0, '/home/claude/canary-platform')
from datetime import datetime
from fastapi import Request
from backend import database as db
from backend.intelligence.false_positive import score_suspicion
from backend.response.alerting import send_alert


async def handle_trigger(token_id: str, request: Request) -> dict:
    """
    Called every time a canary token URL is accessed.
    1. Collect all metadata from the request
    2. Score suspicion level
    3. Save trigger to database
    4. Send alert if suspicion exceeds threshold
    """

    # Collect everything we can from the request
    ip = _get_real_ip(request)
    user_agent = request.headers.get("user-agent", "")
    referer = request.headers.get("referer", "")

    # Collect extra headers that help with fingerprinting
    extra_headers = {
        "accept": request.headers.get("accept", ""),
        "accept-language": request.headers.get("accept-language", ""),
        "accept-encoding": request.headers.get("accept-encoding", ""),
        "connection": request.headers.get("connection", ""),
        "dnt": request.headers.get("dnt", ""),
        "sec-fetch-dest": request.headers.get("sec-fetch-dest", ""),
        "sec-fetch-mode": request.headers.get("sec-fetch-mode", ""),
        "sec-fetch-site": request.headers.get("sec-fetch-site", ""),
    }

    # Canvas fingerprint comes from JS (sent as query param if available)
    canvas_fp = request.query_params.get("cfp", "")

    # Build trigger record
    trigger_data = {
        "token_id": token_id,
        "ip_address": ip,
        "user_agent": user_agent,
        "referer": referer,
        "ja3_fingerprint": "",   # Requires TLS termination — placeholder
        "canvas_fp": canvas_fp,
        "geo_country": "",       # Can add ip-api.com lookup here
        "geo_city": "",
        "extra_headers": extra_headers,
        "suspicion_score": 0.0,
    }

    # Score the trigger
    token = db.get_token(token_id)
    suspicion = score_suspicion(trigger_data, token)
    trigger_data["suspicion_score"] = suspicion

    # Save to database
    trigger_id = db.save_trigger(trigger_data)

    # Alert if suspicious enough
    if suspicion >= 0.4 and token:
        await send_alert(token, trigger_data, trigger_id)

    return {
        "token_id": token_id,
        "trigger_id": trigger_id,
        "suspicion_score": suspicion,
        "ip": ip
    }


def _get_real_ip(request: Request) -> str:
    """Extract real IP, checking proxy headers first."""
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    real_ip = request.headers.get("x-real-ip")
    if real_ip:
        return real_ip
    return request.client.host if request.client else "unknown"
