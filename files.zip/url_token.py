"""URL Canary Token — simplest type, highest reliability."""

import sys
sys.path.insert(0, '/home/claude/canary-platform')
from backend.tokens.base import BaseToken, TokenAsset


class UrlToken(BaseToken):
    TOKEN_TYPE = "url"

    def generate(self, label: str, context: str = "") -> TokenAsset:
        return TokenAsset(
            token_id=self.token_id,
            token_type=self.TOKEN_TYPE,
            label=label,
            tracking_url=self.tracking_url,
            file_path=None,
            raw_value=self.tracking_url,
            instructions=(
                f"Plant this URL anywhere an attacker might click it:\n"
                f"  {self.tracking_url}\n\n"
                f"Good locations: fake internal wiki pages, README files,\n"
                f"phishing simulation emails, or shared documents."
            ),
            metadata={"context": context}
        )
