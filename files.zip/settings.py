"""
Canary Platform — Central Configuration
All settings in one place. Edit this file to configure your system.
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
DATABASE_PATH = BASE_DIR / "database" / "canary.db"
OUTPUT_DIR = BASE_DIR / "generated_tokens"
OUTPUT_DIR.mkdir(exist_ok=True)

HOST = "0.0.0.0"
PORT = 8000
BASE_URL = os.getenv("CANARY_BASE_URL", f"http://localhost:{PORT}")

URL_OBFUSCATION_DEPTH = 2
FAKE_PATH_SEGMENTS = [
    "cdn-assets", "static", "assets", "media", "resources",
    "v2", "api", "content", "files", "data", "dist", "public"
]

ALERT_EMAIL_ENABLED = False
SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USER = os.getenv("SMTP_USER", "your@gmail.com")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "your_app_password")
ALERT_RECIPIENT = os.getenv("ALERT_RECIPIENT", "your@gmail.com")
SLACK_WEBHOOK_URL = os.getenv("SLACK_WEBHOOK_URL", "")

BUSINESS_HOURS_START = 8
BUSINESS_HOURS_END = 18
ALERT_THRESHOLD = 0.4

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
LLM_MODEL = "claude-sonnet-4-20250514"
