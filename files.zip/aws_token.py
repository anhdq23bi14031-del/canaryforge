"""
AWS Credential Canary Token.
Generates fake-but-plausible AWS access keys using a RANDOMIZED account ID
— not linked to any known canary infrastructure (unlike canarytokens.org).
This defeats TruffleHog ARN fingerprinting.
"""

import sys, random, string, struct, base64, hashlib
sys.path.insert(0, '/home/claude/canary-platform')
from backend.tokens.base import BaseToken, TokenAsset


def _encode_account_id(account_id: int) -> str:
    """
    Encode account ID into the access key format (positions 4-12).
    Based on Tal Be'ery's research on AWS key structure.
    We use this knowledge to CREATE undetectable keys by randomizing the account.
    """
    mask = 0x7fffffffff80
    e = account_id << 7
    encoded = []
    for _ in range(6):
        encoded.append(e & 0x3f)
        e >>= 6
    # Base32-encode
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
    return "".join(alphabet[b] for b in reversed(encoded))


def generate_fake_aws_key() -> tuple[str, str]:
    """
    Generate a fake AWS access key with a RANDOM account ID.
    Unlike canarytokens.org which always uses Thinkst's ~6 account IDs,
    this uses a randomized account that cannot be fingerprinted.
    """
    # Random 12-digit AWS account ID (not linked to any known canary provider)
    fake_account_id = random.randint(100000000000, 999999999999)
    encoded = _encode_account_id(fake_account_id)

    # Random suffix (4 chars)
    suffix = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
    access_key = f"AKIA{encoded}{suffix}"

    # Secret key — 40 random chars (base64-like, AWS standard format)
    secret_chars = string.ascii_letters + string.digits + '/+'
    secret_key = ''.join(random.choices(secret_chars, k=40))

    return access_key, secret_key


class AwsToken(BaseToken):
    TOKEN_TYPE = "aws"

    def generate(self, label: str, context: str = "") -> TokenAsset:
        access_key, secret_key = generate_fake_aws_key()

        # Fake .env / credentials file content
        credentials_content = f"""[default]
aws_access_key_id = {access_key}
aws_secret_access_key = {secret_key}
region = ap-southeast-1
"""

        # Also generate a fake .env format
        env_content = f"""# AWS Configuration
AWS_ACCESS_KEY_ID={access_key}
AWS_SECRET_ACCESS_KEY={secret_key}
AWS_DEFAULT_REGION=ap-southeast-1
"""

        return TokenAsset(
            token_id=self.token_id,
            token_type=self.TOKEN_TYPE,
            label=label,
            tracking_url=self.tracking_url,
            file_path=None,
            raw_value=f"{access_key}:{secret_key}",
            instructions=(
                f"Plant these fake AWS credentials in a location attackers scan:\n\n"
                f"~/.aws/credentials format:\n{credentials_content}\n"
                f".env format:\n{env_content}\n"
                f"Note: These keys use a randomized account ID — "
                f"TruffleHog cannot fingerprint them as canary tokens.\n"
                f"Alert URL (for manual testing): {self.tracking_url}"
            ),
            metadata={
                "context": context,
                "access_key": access_key,
                "secret_key": secret_key,
                "note": "Randomized account ID — not linked to known canary infrastructure"
            }
        )
