"""
Response Engine — sends alerts when tokens are triggered.
Supports: console (always), email (optional), Slack (optional).
"""

import sys, json, smtplib, urllib.request
sys.path.insert(0, '/home/claude/canary-platform')
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config import settings
from backend.intelligence.false_positive import suspicion_label


async def send_alert(token: dict, trigger: dict, trigger_id: int):
    """Main alert dispatcher — routes to all configured channels."""
    score = trigger.get("suspicion_score", 0)
    label = suspicion_label(score)
    timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

    summary = (
        f"[CANARY ALERT] {label}\n"
        f"Token:     {token.get('label')} ({token.get('type')})\n"
        f"Token ID:  {token.get('id')}\n"
        f"Trigger:   #{trigger_id} at {timestamp}\n"
        f"IP:        {trigger.get('ip_address', 'unknown')}\n"
        f"UA:        {trigger.get('user_agent', 'unknown')[:80]}\n"
        f"Score:     {score:.2f}\n"
    )

    # Always log to console
    print("\n" + "="*50)
    print(summary)
    print("="*50 + "\n")

    # Email alert
    if settings.ALERT_EMAIL_ENABLED:
        _send_email(token, trigger, summary, timestamp, label)

    # Slack alert
    if settings.SLACK_WEBHOOK_URL:
        _send_slack(token, trigger, summary, label)


def _send_email(token, trigger, summary, timestamp, label):
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"[Canary] {label} — {token.get('label')} triggered"
        msg["From"] = settings.SMTP_USER
        msg["To"] = settings.ALERT_RECIPIENT

        html = f"""
        <html><body style="font-family:monospace;background:#0d1117;color:#c9d1d9;padding:20px;">
        <h2 style="color:#f85149;">{label} — Canary Token Triggered</h2>
        <table style="border-collapse:collapse;width:100%;">
            <tr><td style="padding:8px;border:1px solid #30363d;color:#8b949e;">Token</td>
                <td style="padding:8px;border:1px solid #30363d;">{token.get('label')}</td></tr>
            <tr><td style="padding:8px;border:1px solid #30363d;color:#8b949e;">Type</td>
                <td style="padding:8px;border:1px solid #30363d;">{token.get('type')}</td></tr>
            <tr><td style="padding:8px;border:1px solid #30363d;color:#8b949e;">Time</td>
                <td style="padding:8px;border:1px solid #30363d;">{timestamp}</td></tr>
            <tr><td style="padding:8px;border:1px solid #30363d;color:#8b949e;">IP</td>
                <td style="padding:8px;border:1px solid #30363d;">{trigger.get('ip_address')}</td></tr>
            <tr><td style="padding:8px;border:1px solid #30363d;color:#8b949e;">User Agent</td>
                <td style="padding:8px;border:1px solid #30363d;">{trigger.get('user_agent', '')[:120]}</td></tr>
            <tr><td style="padding:8px;border:1px solid #30363d;color:#8b949e;">Suspicion</td>
                <td style="padding:8px;border:1px solid #30363d;">{trigger.get('suspicion_score'):.2f}</td></tr>
        </table>
        <p style="color:#8b949e;font-size:12px;">Canary Platform — Anti-Fingerprint Edition</p>
        </body></html>
        """

        msg.attach(MIMEText(summary, "plain"))
        msg.attach(MIMEText(html, "html"))

        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
            server.starttls()
            server.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
            server.send_message(msg)
        print("[Alert] Email sent.")
    except Exception as e:
        print(f"[Alert] Email failed: {e}")


def _send_slack(token, trigger, summary, label):
    try:
        color = "#f85149" if "CRITICAL" in label else "#d29922" if "HIGH" in label else "#3fb950"
        payload = {
            "attachments": [{
                "color": color,
                "title": f"Canary Token Triggered — {token.get('label')}",
                "text": f"```{summary}```",
                "footer": "Canary Platform"
            }]
        }
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            settings.SLACK_WEBHOOK_URL,
            data=data,
            headers={"Content-Type": "application/json"}
        )
        urllib.request.urlopen(req, timeout=5)
        print("[Alert] Slack sent.")
    except Exception as e:
        print(f"[Alert] Slack failed: {e}")
