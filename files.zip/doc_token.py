"""
Document Canary Tokens — Word, PDF, Excel.
Embeds a hidden 1x1 tracking image that fires when the document is opened.
"""

import sys, os
sys.path.insert(0, '/home/claude/canary-platform')
from backend.tokens.base import BaseToken, TokenAsset
from config.settings import OUTPUT_DIR
from pathlib import Path


class WordToken(BaseToken):
    TOKEN_TYPE = "word"

    def generate(self, label: str, context: str = "") -> TokenAsset:
        try:
            from docx import Document
            from docx.shared import Inches, Pt
            from docx.oxml.ns import qn
            from docx.oxml import OxmlElement
        except ImportError:
            raise ImportError("Run: pip install python-docx")

        doc = Document()

        # Add plausible-looking content
        doc.add_heading(label, 0)
        doc.add_paragraph(
            f"This document contains confidential information. "
            f"Unauthorized access or distribution is strictly prohibited."
        )
        doc.add_paragraph(context or "Internal use only.")

        # Embed hidden tracking image via XML relationship
        # This fires an HTTP request when Word opens the document
        part = doc.part
        rId = part.relate_to(
            self.tracking_url,
            "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image",
            is_external=True
        )

        # Create a 1x1 hidden inline image element
        run = doc.paragraphs[-1].add_run()
        inline = OxmlElement("w:drawing")
        inline_xml = f"""
        <wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
                   distT="0" distB="0" distL="0" distR="0">
          <wp:extent cx="1" cy="1"/>
          <wp:docPr id="1" name="beacon"/>
          <a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
            <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">
              <pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">
                <pic:nvPicPr>
                  <pic:cNvPr id="0" name="beacon"/>
                  <pic:cNvPicPr/>
                </pic:nvPicPr>
                <pic:blipFill>
                  <a:blip r:embed="{rId}"
                          xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/>
                  <a:stretch><a:fillRect/></a:stretch>
                </pic:blipFill>
                <pic:spPr>
                  <a:xfrm><a:off x="0" y="0"/><a:ext cx="1" cy="1"/></a:xfrm>
                  <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
                </pic:spPr>
              </pic:pic>
            </a:graphicData>
          </a:graphic>
        </wp:inline>"""

        from lxml import etree
        inline.append(etree.fromstring(inline_xml))
        run._r.append(inline)

        # Save file
        safe_label = "".join(c if c.isalnum() or c in " -_" else "_" for c in label)
        file_path = OUTPUT_DIR / f"{safe_label}_{self.token_id}.docx"
        doc.save(str(file_path))

        return TokenAsset(
            token_id=self.token_id,
            token_type=self.TOKEN_TYPE,
            label=label,
            tracking_url=self.tracking_url,
            file_path=file_path,
            instructions=(
                f"Plant '{file_path.name}' where an attacker would find it valuable.\n"
                f"Token fires when the document is opened in Microsoft Word\n"
                f"with external content loading enabled."
            ),
            metadata={"context": context, "format": "docx"}
        )


class ExcelToken(BaseToken):
    TOKEN_TYPE = "excel"

    def generate(self, label: str, context: str = "") -> TokenAsset:
        try:
            import openpyxl
        except ImportError:
            raise ImportError("Run: pip install openpyxl")

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Sheet1"

        # Add plausible headers
        ws["A1"] = label
        ws["A2"] = "Confidential — Internal Use Only"
        ws["A4"] = "Name"
        ws["B4"] = "Department"
        ws["C4"] = "Value"

        # Embed tracking URL as an external image link in sheet properties
        # Using a defined name with external reference
        ws["A10"] = context or "See attached notes"

        # Add tracking via formula that references external URL
        # WEBSERVICE formula fires HTTP request when sheet calculates
        ws["Z1"] = f'=IFERROR(WEBSERVICE("{self.tracking_url}"),"")'

        safe_label = "".join(c if c.isalnum() or c in " -_" else "_" for c in label)
        file_path = OUTPUT_DIR / f"{safe_label}_{self.token_id}.xlsx"
        wb.save(str(file_path))

        return TokenAsset(
            token_id=self.token_id,
            token_type=self.TOKEN_TYPE,
            label=label,
            tracking_url=self.tracking_url,
            file_path=file_path,
            instructions=(
                f"Plant '{file_path.name}' in a shared drive or folder.\n"
                f"Token fires when opened in Excel with external data enabled."
            ),
            metadata={"context": context, "format": "xlsx"}
        )


class PdfToken(BaseToken):
    TOKEN_TYPE = "pdf"

    def generate(self, label: str, context: str = "") -> TokenAsset:
        try:
            from reportlab.pdfgen import canvas
            from reportlab.lib.pagesizes import A4
        except ImportError:
            raise ImportError("Run: pip install reportlab")

        safe_label = "".join(c if c.isalnum() or c in " -_" else "_" for c in label)
        file_path = OUTPUT_DIR / f"{safe_label}_{self.token_id}.pdf"

        c = canvas.Canvas(str(file_path), pagesize=A4)
        width, height = A4

        # Add content
        c.setFont("Helvetica-Bold", 18)
        c.drawString(50, height - 80, label)
        c.setFont("Helvetica", 10)
        c.drawString(50, height - 110, "CONFIDENTIAL — INTERNAL USE ONLY")
        c.drawString(50, height - 140, context or "Unauthorized distribution is prohibited.")

        # Embed tracking URL as a 1x1 invisible link annotation
        # PDF readers that auto-load will trigger this
        from reportlab.lib.colors import white
        c.setFillColor(white)
        c.rect(0, 0, 1, 1, fill=1, stroke=0)
        c.linkURL(self.tracking_url, (0, 0, 1, 1), relative=0)

        c.save()

        return TokenAsset(
            token_id=self.token_id,
            token_type=self.TOKEN_TYPE,
            label=label,
            tracking_url=self.tracking_url,
            file_path=file_path,
            instructions=(
                f"Plant '{file_path.name}' as a decoy document.\n"
                f"Token fires when opened in PDF readers that load remote resources."
            ),
            metadata={"context": context, "format": "pdf"}
        )
