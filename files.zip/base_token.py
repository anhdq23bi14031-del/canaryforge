"""
BaseToken — The interface every token type must implement.
This is the architectural core that keeps the system unified and extensible.
"""

import uuid
import random
import sys
sys.path.insert(0, '/home/claude/canary-platform')
from config import settings
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class TokenAsset:
    """What gets returned after a token is generated."""
    token_id: str
    token_type: str
    label: str
    tracking_url: str
    file_path: str | None = None   # For document tokens
    raw_value: str | None = None   # For credential tokens (the fake key etc.)
    instructions: str = ""         # Human-readable: "plant this file in..."
    metadata: dict = field(default_factory=dict)


class BaseToken(ABC):
    """
    Every token type inherits from this.
    To add a new token type: create a class, implement generate() and embed().
    """

    TOKEN_TYPE: str = "base"

    def __init__(self):
        self.token_id = self._new_id()
        self.tracking_url = self._build_tracking_url()

    def _new_id(self) -> str:
        """Generate a short, unique token ID."""
        return uuid.uuid4().hex[:12]

    def _build_tracking_url(self) -> str:
        """
        Build an obfuscated tracking URL.
        Instead of /track/abc123, generates /cdn-assets/static/abc123/pixel.gif
        This makes the URL look like a legitimate CDN asset request.
        """
        segments = random.sample(
            settings.FAKE_PATH_SEGMENTS,
            k=settings.URL_OBFUSCATION_DEPTH
        )
        path = "/".join(segments)
        # Add a random-looking filename suffix for document tokens
        suffix = random.choice(["pixel.gif", "beacon.png", "track", "1x1.gif", ""])
        if suffix:
            return f"{settings.BASE_URL}/t/{path}/{self.token_id}/{suffix}"
        return f"{settings.BASE_URL}/t/{path}/{self.token_id}"

    def to_db_dict(self, asset: TokenAsset) -> dict:
        """Convert a TokenAsset to the dict format saved in the database."""
        return {
            "id": asset.token_id,
            "type": asset.token_type,
            "label": asset.label,
            "description": asset.instructions,
            "tracking_url": asset.tracking_url,
            "file_path": str(asset.file_path) if asset.file_path else None,
            "metadata": asset.metadata,
        }

    @abstractmethod
    def generate(self, label: str, context: str = "") -> TokenAsset:
        """
        Generate the token asset.
        label   — human-readable name e.g. "Q3 Salary Report"
        context — hint for LLM content generation e.g. "HR document, Malaysian fintech"
        """
        pass
