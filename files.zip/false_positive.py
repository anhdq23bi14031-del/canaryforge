"""
False Positive Filter — behavioral scoring engine.
Scores each trigger 0.0 (definitely legitimate) to 1.0 (definitely malicious).
Only fires alerts above the configured threshold.
"""

import sys
sys.path.insert(0, '/home/claude/canary-platform')
from datetime import datetime
from config.settings import BUSINESS_HOURS_START, BUSINESS_HOURS_END


# Known legitimate bot/crawler user agents to filter out
KNOWN_BOTS = [
    "googlebot", "bingbot", "slurp", "duckduckbot", "baiduspider",
    "yandexbot", "facebot", "ia_archiver", "python-requests",
    "curl/", "wget/", "go-http-client", "okhttp", "axios",
    "postman", "insomnia"
]

# Suspicious patterns in user agents
SUSPICIOUS_UA_PATTERNS = [
    "python", "curl", "wget", "go-http", "java/", "ruby",
    "perl", "php", "scrapy", "nikto", "nmap", "masscan"
]


def score_suspicion(trigger: dict, token: dict | None) -> float:
    """
    Score a trigger's suspicion level.
    Returns float 0.0–1.0. Higher = more suspicious.
    
    Scoring breakdown:
    - Off-hours access:          +0.25
    - Suspicious user agent:     +0.30
    - Known bot/scanner:         +0.20
    - No referer (direct):       +0.10
    - Canvas FP absent:          +0.05
    - Repeated rapid access:     +0.20 (future)
    """
    score = 0.0
    ua = (trigger.get("user_agent") or "").lower()
    now = datetime.utcnow()

    # 1. Time-of-day analysis
    hour = now.hour
    if not (BUSINESS_HOURS_START <= hour <= BUSINESS_HOURS_END):
        score += 0.25  # Off-hours access is suspicious

    # 2. User agent analysis
    if not ua:
        score += 0.30  # No UA at all is very suspicious
    elif any(bot in ua for bot in KNOWN_BOTS):
        score += 0.20  # Known crawlers — likely noise, moderate suspicion
    elif any(pattern in ua for pattern in SUSPICIOUS_UA_PATTERNS):
        score += 0.30  # Programmatic access tools

    # 3. Referer analysis
    referer = (trigger.get("referer") or "").lower()
    if not referer:
        score += 0.10  # Direct access (no referring page) slightly suspicious

    # 4. Canvas fingerprint absent
    if not trigger.get("canvas_fp"):
        score += 0.05  # Slight signal — real browsers usually have this

    # 5. Headless browser signals
    extra = trigger.get("extra_headers", {})
    if isinstance(extra, str):
        import json
        try:
            extra = json.loads(extra)
        except Exception:
            extra = {}

    sec_fetch_dest = extra.get("sec-fetch-dest", "")
    if sec_fetch_dest in ("", "empty"):
        score += 0.10  # Missing modern browser security headers

    # Cap at 1.0
    return min(round(score, 2), 1.0)


def suspicion_label(score: float) -> str:
    """Human-readable label for a suspicion score."""
    if score >= 0.8:
        return "🔴 CRITICAL"
    elif score >= 0.6:
        return "🟠 HIGH"
    elif score >= 0.4:
        return "🟡 MEDIUM"
    elif score >= 0.2:
        return "🔵 LOW"
    else:
        return "⚪ NOISE"
