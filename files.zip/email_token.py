"""Email Pixel Token — fires when email is opened."""

import sys
sys.path.insert(0, '/home/claude/canary-platform')
from backend.tokens.base import BaseToken, TokenAsset


class EmailToken(BaseToken):
    TOKEN_TYPE = "email"

    def generate(self, label: str, context: str = "") -> TokenAsset:
        # The pixel tag to embed in any HTML email
        pixel_html = (
            f'<img src="{self.tracking_url}" '
            f'width="1" height="1" style="display:none;border:0;" '
            f'alt="" />'
        )

        full_email_example = f"""
To: [recipient]
Subject: {label}
Content-Type: text/html

<html><body>
<p>{context or 'Please review the attached information.'}</p>
{pixel_html}
</body></html>
"""

        return TokenAsset(
            token_id=self.token_id,
            token_type=self.TOKEN_TYPE,
            label=label,
            tracking_url=self.tracking_url,
            file_path=None,
            raw_value=pixel_html,
            instructions=(
                f"Embed this pixel tag in any HTML email:\n\n"
                f"{pixel_html}\n\n"
                f"Token fires when the email is opened with image loading enabled."
            ),
            metadata={"context": context, "pixel_html": pixel_html}
        )
