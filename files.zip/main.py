"""
Canary Platform — FastAPI Backend
Serves both the REST API (for CLI) and the HTML dashboard (for browser).
"""

import sys, json
sys.path.insert(0, '/home/claude/canary-platform')

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, Response, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend import database as db
from backend.capture.server import handle_trigger
from config.settings import BASE_URL

app = FastAPI(title="Canary Platform", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Startup ────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    db.init_db()
    print(f"\n🐦 Canary Platform running at {BASE_URL}")
    print(f"   Dashboard: {BASE_URL}/dashboard")
    print(f"   API docs:  {BASE_URL}/docs\n")


# ── Token Creation API ─────────────────────────────────────────────────────

class CreateTokenRequest(BaseModel):
    type: str          # url | word | pdf | excel | email | aws
    label: str         # Human-readable name
    context: str = ""  # Optional context for LLM generation


@app.post("/api/tokens")
async def create_token(req: CreateTokenRequest):
    """Create a new canary token."""
    token_map = {
        "url":   "backend.tokens.url_token.UrlToken",
        "word":  "backend.tokens.doc_token.WordToken",
        "pdf":   "backend.tokens.doc_token.PdfToken",
        "excel": "backend.tokens.doc_token.ExcelToken",
        "email": "backend.tokens.email_token.EmailToken",
        "aws":   "backend.tokens.aws_token.AwsToken",
    }

    if req.type not in token_map:
        raise HTTPException(400, f"Unknown token type. Choose: {list(token_map.keys())}")

    # Dynamically import the token class
    module_path, class_name = token_map[req.type].rsplit(".", 1)
    import importlib
    module = importlib.import_module(module_path)
    TokenClass = getattr(module, class_name)

    generator = TokenClass()
    asset = generator.generate(label=req.label, context=req.context)

    # Save to database
    db.save_token(generator.to_db_dict(asset))

    return {
        "token_id": asset.token_id,
        "type": asset.token_type,
        "label": asset.label,
        "tracking_url": asset.tracking_url,
        "file_path": str(asset.file_path) if asset.file_path else None,
        "raw_value": asset.raw_value,
        "instructions": asset.instructions,
        "metadata": asset.metadata,
    }


# ── Token Management API ───────────────────────────────────────────────────

@app.get("/api/tokens")
async def list_tokens():
    return db.get_all_tokens()


@app.get("/api/tokens/{token_id}")
async def get_token(token_id: str):
    token = db.get_token(token_id)
    if not token:
        raise HTTPException(404, "Token not found")
    token["triggers"] = db.get_triggers(token_id)
    return token


@app.delete("/api/tokens/{token_id}")
async def delete_token(token_id: str):
    db.deactivate_token(token_id)
    return {"status": "deactivated", "token_id": token_id}


# ── Trigger Capture ────────────────────────────────────────────────────────

# Catch-all route for obfuscated tracking URLs
# Matches: /t/cdn-assets/static/abc123/pixel.gif  or  /t/assets/data/abc123
@app.get("/t/{path:path}")
async def capture_trigger(path: str, request: Request, cfp: str = ""):
    """
    Main capture endpoint. The token ID is always the last path segment
    before any file extension.
    """
    # Extract token_id from obfuscated path
    # Path format: segment1/segment2/.../token_id[/filename.ext]
    parts = path.rstrip("/").split("/")

    # Find token_id — it's the part that matches a known token
    token_id = None
    for part in reversed(parts):
        # Strip file extensions
        clean = part.split(".")[0]
        if db.get_token(clean):
            token_id = clean
            break

    if not token_id:
        # Return a pixel anyway (don't reveal the endpoint doesn't match)
        return _pixel_response()

    await handle_trigger(token_id, request)
    return _pixel_response()


def _pixel_response():
    """Return a 1x1 transparent GIF — indistinguishable from a real tracking pixel."""
    gif = (
        b"GIF89a\x01\x00\x01\x00\x80\x00\x00\xff\xff\xff"
        b"\x00\x00\x00!\xf9\x04\x00\x00\x00\x00\x00,"
        b"\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;"
    )
    return Response(content=gif, media_type="image/gif")


# ── Alert History API ──────────────────────────────────────────────────────

@app.get("/api/alerts")
async def get_alerts():
    return db.get_recent_alerts()


@app.get("/api/triggers")
async def get_all_triggers():
    return db.get_triggers()


# ── Dashboard ──────────────────────────────────────────────────────────────

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard():
    with open("/home/claude/canary-platform/frontend/dashboard.html") as f:
        return f.read()


@app.get("/", response_class=HTMLResponse)
async def root():
    return '<meta http-equiv="refresh" content="0; url=/dashboard">'
