#!/usr/bin/env python3
"""
Canary Platform — CLI Tool
Usage: python cli/canary.py <command> [options]

Commands:
  create   --type <type> --label <name> [--context <hint>]
  list     Show all tokens
  alerts   Show recent alerts
  triggers --id <token_id>
  delete   --id <token_id>
  test     --id <token_id>   Simulate a trigger for testing
"""

import sys, json, argparse, urllib.request, urllib.parse
sys.path.insert(0, '/home/claude/canary-platform')

API = "http://localhost:8000/api"

COLORS = {
    "red":    "\033[91m",
    "green":  "\033[92m",
    "yellow": "\033[93m",
    "blue":   "\033[94m",
    "cyan":   "\033[96m",
    "white":  "\033[97m",
    "reset":  "\033[0m",
    "bold":   "\033[1m",
    "dim":    "\033[2m",
}

def c(color, text): return f"{COLORS[color]}{text}{COLORS['reset']}"
def bold(text): return f"{COLORS['bold']}{text}{COLORS['reset']}"
def header(text): print(f"\n{c('cyan', '─'*50)}\n{bold(c('white', text))}\n{c('cyan', '─'*50)}")


def api_post(endpoint, data):
    body = json.dumps(data).encode()
    req = urllib.request.Request(
        f"{API}/{endpoint}",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())


def api_get(endpoint):
    with urllib.request.urlopen(f"{API}/{endpoint}") as r:
        return json.loads(r.read())


def api_delete(endpoint):
    req = urllib.request.Request(f"{API}/{endpoint}", method="DELETE")
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())


def cmd_create(args):
    header("Creating Canary Token")
    print(f"  Type:    {c('yellow', args.type)}")
    print(f"  Label:   {args.label}")
    if args.context:
        print(f"  Context: {args.context}")
    print()

    try:
        result = api_post("tokens", {
            "type": args.type,
            "label": args.label,
            "context": args.context or ""
        })
    except Exception as e:
        print(c("red", f"Error: {e}"))
        print(c("dim", "Is the server running? Start with: python -m uvicorn backend.main:app --reload"))
        sys.exit(1)

    print(c("green", "✓ Token created successfully!\n"))
    print(f"  {bold('Token ID:')}     {c('cyan', result['token_id'])}")
    print(f"  {bold('Type:')}         {result['type']}")
    print(f"  {bold('Tracking URL:')} {c('blue', result['tracking_url'])}")

    if result.get("file_path"):
        print(f"  {bold('File:')}         {c('yellow', result['file_path'])}")

    if result.get("raw_value") and result["type"] in ("aws", "email"):
        print(f"\n  {bold('Value:')}")
        for line in result["raw_value"].split("\n"):
            print(f"    {c('dim', line)}")

    print(f"\n  {bold('Instructions:')}")
    for line in result["instructions"].split("\n"):
        print(f"    {line}")


def cmd_list(args):
    header("Active Canary Tokens")
    tokens = api_get("tokens")

    if not tokens:
        print(c("dim", "  No tokens yet. Create one with: canary create"))
        return

    type_colors = {
        "url": "blue", "word": "cyan", "pdf": "red",
        "excel": "green", "email": "yellow", "aws": "white"
    }

    for t in tokens:
        tc = type_colors.get(t["type"], "white")
        trigger_info = (
            c("red", f"  ⚡ {t['trigger_count']} trigger(s)") 
            if t["trigger_count"] > 0 
            else c("dim", "  No triggers")
        )
        active = c("green", "●") if t["is_active"] else c("dim", "○")
        print(f"\n  {active} {bold(t['label'])}")
        print(f"     ID:       {c('dim', t['id'])}")
        print(f"     Type:     {c(tc, t['type'].upper())}")
        print(f"     Created:  {c('dim', t['created_at'][:19])}")
        print(f"     Status:  {trigger_info}")


def cmd_alerts(args):
    header("Recent Alerts")
    alerts = api_get("alerts")

    if not alerts:
        print(c("dim", "  No alerts yet. Plant some tokens!"))
        return

    score_color = lambda s: "red" if s >= 0.8 else "yellow" if s >= 0.4 else "dim"

    for a in alerts:
        sc = a["suspicion_score"]
        print(f"\n  {c(score_color(sc), f'[{sc:.2f}]')} {bold(a.get('label', 'Unknown'))}")
        print(f"     Time:  {c('dim', a['triggered_at'][:19])}")
        print(f"     IP:    {a.get('ip_address', 'unknown')}")
        print(f"     UA:    {c('dim', (a.get('user_agent') or '')[:70])}")
        print(f"     Type:  {a.get('type', '').upper()}")


def cmd_triggers(args):
    if not args.id:
        print(c("red", "Provide token ID: canary triggers --id <token_id>"))
        sys.exit(1)
    header(f"Triggers for token: {args.id}")
    triggers = api_get(f"tokens/{args.id}")
    for t in triggers.get("triggers", []):
        sc = t["suspicion_score"]
        print(f"\n  [{sc:.2f}] {t['triggered_at'][:19]}")
        print(f"  IP: {t.get('ip_address')}  UA: {(t.get('user_agent') or '')[:60]}")


def cmd_delete(args):
    if not args.id:
        print(c("red", "Provide token ID: canary delete --id <token_id>"))
        sys.exit(1)
    result = api_delete(f"tokens/{args.id}")
    print(c("green", f"✓ Token {args.id} deactivated."))


def cmd_test(args):
    """Simulate a trigger by hitting the tracking URL directly."""
    if not args.id:
        print(c("red", "Provide token ID: canary test --id <token_id>"))
        sys.exit(1)
    token = api_get(f"tokens/{args.id}")
    url = token.get("tracking_url")
    if not url:
        print(c("red", "Token not found or has no tracking URL."))
        sys.exit(1)
    print(f"  Simulating trigger for: {c('yellow', token.get('label'))}")
    print(f"  Hitting: {c('blue', url)}")
    try:
        urllib.request.urlopen(url, timeout=5)
        print(c("green", "  ✓ Trigger sent! Check alerts with: canary alerts"))
    except Exception as e:
        print(c("red", f"  Error: {e}"))


def main():
    parser = argparse.ArgumentParser(
        description="🐦 Canary Platform CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python cli/canary.py create --type url --label "Internal Wiki Link"
  python cli/canary.py create --type word --label "Q3 Salary Sheet" --context "HR document"
  python cli/canary.py create --type aws --label "Dev AWS Keys"
  python cli/canary.py list
  python cli/canary.py alerts
  python cli/canary.py test --id abc123def456
        """
    )

    sub = parser.add_subparsers(dest="command")

    # create
    p_create = sub.add_parser("create", help="Create a new canary token")
    p_create.add_argument("--type", required=True, choices=["url","word","pdf","excel","email","aws"])
    p_create.add_argument("--label", required=True, help="Human-readable name for this token")
    p_create.add_argument("--context", default="", help="Context hint (used for document content)")

    # list
    sub.add_parser("list", help="List all tokens")

    # alerts
    sub.add_parser("alerts", help="Show recent high-suspicion triggers")

    # triggers
    p_trig = sub.add_parser("triggers", help="Show all triggers for a specific token")
    p_trig.add_argument("--id", help="Token ID")

    # delete
    p_del = sub.add_parser("delete", help="Deactivate a token")
    p_del.add_argument("--id", help="Token ID")

    # test
    p_test = sub.add_parser("test", help="Simulate a trigger (for testing)")
    p_test.add_argument("--id", help="Token ID")

    args = parser.parse_args()

    print(bold(c("cyan", "\n🐦 Canary Platform — Anti-Fingerprint Edition")))

    if args.command == "create":   cmd_create(args)
    elif args.command == "list":   cmd_list(args)
    elif args.command == "alerts": cmd_alerts(args)
    elif args.command == "triggers": cmd_triggers(args)
    elif args.command == "delete": cmd_delete(args)
    elif args.command == "test":   cmd_test(args)
    else:
        parser.print_help()

    print()


if __name__ == "__main__":
    main()
